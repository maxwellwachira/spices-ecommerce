<?php
/**
 *  @package     AkeebaFEF
 *  @copyright   Copyright (c)2017-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 *  @license     GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('AKEEBAFEF_VERSION', '1.0.7');
define('AKEEBAFEF_DATE', '2019-01-07');
