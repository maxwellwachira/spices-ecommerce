<?php



// no direct access

// Please respect our hardwork by leaving a little credit for us :)
// Please do not fork this template for re-distribution purpose

defined('_JEXEC') or die('Restricted access'); ?>
<p>&#169;<?php echo $cur_year . ' ' . $csite_name . ' ' . JText :: _('by <a href="http://templateplazza.com" target="_blank">TemplatePlazza</a> - All right reserved');?></p>
